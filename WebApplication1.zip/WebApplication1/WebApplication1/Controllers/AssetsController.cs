using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssetsController : ControllerBase
    {
        private readonly AssetService _assetservice;
        public AssetsController(AssetService assetservice)
        {
            _assetservice = assetservice;
        }
        // GET: api/<CustomersController>
        [HttpGet]
        public ActionResult<List<Asset>> Get() =>
            _assetservice.Get();

        [HttpGet("{id:length(24)}", Name = "GetAsset")]
        public ActionResult<Asset> Get(string id)
        {
            var assetch = _assetservice.Get(id);

            if (assetch == null)
            {
                return NotFound();
            }

            return assetch;
        }

        [HttpPost]
        public ActionResult<Asset> Create(Asset asset)
        {
            _assetservice.Create(asset);

            return CreatedAtRoute("GetAsset", new { id = asset._id.ToString() }, asset);
        }

        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, Asset assetIn)
        {
            var cust = _assetservice.Get(id);

            if (cust == null)
            {
                return NotFound();
            }

            _assetservice.Update(id, assetIn);

            return NoContent();
        }

        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            var asst = _assetservice.Get(id);

            if (asst == null)
            {
                return NotFound();
            }

            _assetservice.Remove(asst._id);

            return NoContent();
        }
    }
}
