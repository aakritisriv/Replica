using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TanksController : ControllerBase
    {

    private readonly TankService _tankService;
    public TanksController(TankService tankservice)
    {
        _tankService = tankservice;
    }
    // Get All tanks
    [HttpGet]
        public ActionResult<List<Tank>> Get() =>
            _tankService.Get();
    // GET /api/tanks/id
    [HttpGet("{id:length(24)}", Name = "GetTank")]
    public ActionResult<Tank> Get(string id)
    {
         var tankch = _tankService.Get(id);

            if (tankch == null)
            {
                return NotFound();
            }

            return tankch;
        
    }

    // GET /api/tanks/my/3
    [HttpGet("my/{id:length(24)}")]
    public ActionResult<List<Tank>> GetbyAssetId(string id)
    {
         var tankch = _tankService.GetbyAssetId(id);

            if (tankch == null)
            {
                return NotFound();
            }

            return tankch;
    }


        [HttpPost]
        public ActionResult<Tank> Create(Tank tank)
        {
            _tankService.Create(tank);

            return CreatedAtRoute("GetTank", new { id = tank._id.ToString() }, tank);
        }

        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, Tank tankIn)
        {
            var cust = _tankService.Get(id);

            if (cust == null)
            {
                return NotFound();
            }

            _tankService.Update(id, tankIn);

            return NoContent();
        }

        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            var cust = _tankService.Get(id);

            if (cust == null)
            {
                return NotFound();
            }

            _tankService.Remove(cust._id);

            return NoContent();
        }//
    }
}
