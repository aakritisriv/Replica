﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        private readonly CustomerService _customerservice;
        public CustomersController(CustomerService customerService)
        {
            _customerservice = customerService;
        }
        // GET: api/<CustomersController>
        [HttpGet]
        public ActionResult<List<Customer>> Get() =>
            _customerservice.Get();

        [HttpGet("{id:length(24)}", Name = "GetCustomer")]
        public ActionResult<Customer> Get(string id)
        {
            var cust = _customerservice.Get(id);

            if (cust == null)
            {
                return NotFound();
            }

            return cust;
        }

        [HttpPost]
        public ActionResult<Customer> Create(Customer customer)
        {
            _customerservice.Create(customer);

            return CreatedAtRoute("GetCustomer", new { id = customer.Id.ToString() }, customer);
        }

        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, Customer customerIn)
        {
            var cust = _customerservice.Get(id);

            if (cust == null)
            {
                return NotFound();
            }

            _customerservice.Update(id, customerIn);

            return NoContent();
        }

        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            var cust = _customerservice.Get(id);

            if (cust == null)
            {
                return NotFound();
            }

            _customerservice.Remove(cust.Id);

            return NoContent();
        }
    }
}
