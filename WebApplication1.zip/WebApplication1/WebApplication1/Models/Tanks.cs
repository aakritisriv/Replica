using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace WebApplication1.Models
{
    public class Tank
    {    
    
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
        public int id{ get; set;}
        public long TankCapacity { get; set; }
        public string TankType { get; set; }
        public double TankLength { get; set; }
        public double TankWidth { get; set; }
        public double TankHeight { get; set; }
        public string TankName { get; set; }
       
        public string AssetId { get; set; }

        }}