using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace WebApplication1.Models
{
    public class Asset
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
        public int id{ get; set;}
        public string Name {get; set;}
        public string Type { get; set; }
        public string Field { get; set; }
        public DateTime addedDate { get; set; } = DateTime.Now;


       
    }
    public class Counter
        {
        public string Id { get; set; }
        public int Value { get; set; }
        }
}
