﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace WebApplication1.Models
{
    public class Customer
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("CustomerName")]
        // public string AccountName { get; set; }

        public string companyName { get; set; }

        public int tankNumberIncrement { get; set; }

        public string SoldTo { get; set; }

        public string accountStatus { get; set; }
    }
}
