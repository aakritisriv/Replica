﻿using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using WebApplication1.Models;
namespace WebApplication1.Services
{
    public class CustomerService
    {

        private readonly IMongoCollection<Customer> _customers;

        public CustomerService(ICustomerDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _customers = database.GetCollection<Customer>(settings.CustomerCollectionName);
        }

        public List<Customer> Get() =>
            _customers.Find(customer => true).ToList();

        public Customer Get(string id) =>
            _customers.Find<Customer>(customer => customer.Id == id).FirstOrDefault();

        public Customer Create(Customer customer)
        {
            _customers.InsertOne(customer);
            return customer;
        }

        public void Update(string id, Customer CustomerIn) =>
            _customers.ReplaceOne(customer => customer.Id == id, CustomerIn);

        public void Remove(Customer CustomerIn) =>
            _customers.DeleteOne(customer => customer.Id == CustomerIn.Id);

        public void Remove(string id) =>
            _customers.DeleteOne(customer => customer.Id == id);

    }
}
