using MongoDB.Driver;
using MongoDB.Driver.Linq;
using System.Collections.Generic;
using System.Linq;
using WebApplication1.Models;
namespace WebApplication1.Services
{
    public class TankService
    {

        private readonly IMongoCollection<Tank> _tank;

        public TankService(ICustomerDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            
            _tank = database.GetCollection<Tank>("Tanks");
        }

        public List<Tank> Get() =>
            _tank.Find(tank => true).ToList();

        public Tank Get(string id) =>
            _tank.Find<Tank>(tank => tank._id == id).FirstOrDefault();

         public int TankFindByLatestID(){
            var index = 0;
            var list =  _tank.Find(tank => true).ToList();
            var sortedList = list.OrderByDescending(Tank=> Tank._id).ToList();
            var limit = sortedList.FirstOrDefault();
            if(limit == null){
                index = 1;
            }
            else{
                var obj = limit.id;
                if(obj == 0 ){
                index = 1;
                
                }
                else{
                    index = obj + 1;
                    
                }
           
            }
           
             return index;
           
            
        }
        public Tank Create(Tank tank)
        {
            tank.id = this.TankFindByLatestID();
            _tank.InsertOne(tank);
            return tank;
        }
       

        public List<Tank> GetbyAssetId(string id) {
            var list =  _tank.Find(tank => tank.AssetId == id).ToList();
           // var sortedList = list.OrderByDescending(Tank=> Tank._id).ToList();
            return list;
        }  
          
        

        public void Update(string id, Tank TankIn) =>
            _tank.ReplaceOne(tank => tank._id == id, TankIn);

        public void Remove(Tank TankIn) =>
            _tank.DeleteOne(tank => tank._id == TankIn._id);

        public void Remove(string id) =>
            _tank.DeleteOne(tank => tank._id == id);

    }
}
