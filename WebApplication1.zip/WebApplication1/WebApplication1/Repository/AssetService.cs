using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using WebApplication1.Models;
namespace WebApplication1.Services
{
    public class AssetService
    {

        private readonly IMongoCollection<Asset> _asset;

        public AssetService(ICustomerDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            
            _asset = database.GetCollection<Asset>("Assets");

        }

        public List<Asset> Get() =>
            _asset.Find(asset => true).ToList();

        public Asset Get(string id) =>
            _asset.Find<Asset>(asset => asset._id == id).FirstOrDefault();
        public int CreateFindByLatestID(){
            var index = 0;
            var list =  _asset.Find(asset => true).ToList();
            var sortedList = list.OrderByDescending(Asset=> Asset._id).ToList();
            var limit = sortedList.FirstOrDefault();
            if(limit == null){
                index = 1;
            }
            else{
                var obj = limit.id;
                if(obj == 0 ){
                index = 1;
                
                }
                else{
                    index = obj + 1;
                    
                }
           
            }
           
             return index;
           
            
        }
        public Asset Create(Asset asset)
        {
            asset.id = this.CreateFindByLatestID();
            _asset.InsertOne(asset);
            return asset;
        }
        
        public void Update(string id, Asset AssetIn) =>
            _asset.ReplaceOne(asset => asset._id == id, AssetIn);

        public void Remove(Asset AssetIn) =>
            _asset.DeleteOne(asset => asset._id == AssetIn._id);

        public void Remove(string id) =>
            _asset.DeleteOne(asset => asset._id == id);

    }
}
